﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Media.Core;
using Windows.Media.Playback;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Animation;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.Xaml.Navigation;

// La plantilla de elemento Control de usuario está documentada en https://go.microsoft.com/fwlink/?LinkId=234236

namespace ControlUsuario_IPO2
{
    public sealed partial class DragoniteCSD : UserControl, iPokemon
    {
        public DragoniteCSD()
        {
            this.InitializeComponent();
            this.IsTabStop = true;
            this.KeyDown += ControlTeclas;

            defaultStoryboard = (Storyboard)this.Resources["Default"];
            defaultStoryboard.Begin();

        }
        Storyboard defaultStoryboard;
        DispatcherTimer dtTime;

        private Boolean cansado = false;
        private Boolean herido = false;
        private MediaPlayer mpsonidos = new MediaPlayer();
        private Storyboard sb = new Storyboard();

        public double Vida { get; set; } = 80;
        public double Energia { get; set; } = 100;
        public string Nombre { get; set; } = "Dragonite";
        public string Categoria { get; set; } = "Dragon";
        public string Tipo { get; set; } = "Dragón/Volador";
        public double Altura { get; set; } = 2.2; // En metros
        public double Peso { get; set; } = 210; // En kilos
        public string Evolucion { get; set; } = "Dragonair";
        public string Descripcion { get; set; } = "Dragonite es un Pokémon legendario que posee la habilidad de volar a velocidades impresionantes, alcanzando hasta 1,500 kilómetros por hora. Su imponente tamaño y su envergadura lo hacen una criatura majestuosa en los cielos. A pesar de su apariencia intimidante, Dragonite es conocido por su naturaleza amigable y protectora hacia aquellos que considera sus amigos. Sin embargo, cuando se enfrenta a una amenaza, puede desatar un poderío increíble en la batalla, utilizando su fuerza física y sus poderosos ataques de tipo dragón y volador. Su evolución a partir de Dragonair es un símbolo de la madurez y la fortaleza que alcanza este Pokémon, convirtiéndose en un aliado valioso para cualquier Entrenador que lo tenga a su lado.";

        private void ControlTeclas(object sender, KeyRoutedEventArgs e)
        {
            mpsonidos.Pause();
            defaultStoryboard.Stop();

            switch (e.Key)
            {
                case Windows.System.VirtualKey.Number1:
                    AnimacionAtaqueFlojo();
                    break;

                case Windows.System.VirtualKey.Number2:
                    AnimacionAtaqueFuerte();
                    break;

                case Windows.System.VirtualKey.Number3:
                    AnimacionDefensa();
                    break;

                case Windows.System.VirtualKey.Number4:
                    AnimacionDescansar();
                    break;

                case Windows.System.VirtualKey.Number5:
                    AnimacionHerido();
                    break;

                case Windows.System.VirtualKey.Number6:
                    AnimacionDerrota();
                    break;

                case Windows.System.VirtualKey.Number7:
                    img_escudoesfera.Visibility = Visibility.Collapsed;
                    ResetAnimation(cansado, herido);
                    break;

                case Windows.System.VirtualKey.Number8:
                    AnimacionCansado();
                    break;

                default:
                    // Si no se presiona ninguna tecla válida, vuelve a iniciar la animación predeterminada
                    defaultStoryboard.Begin();
                    break;
            }

        }

        private void ReproducirAtaqueDespuesEnfado(MediaPlayer sender, object args)
        {
            mpsonidos.MediaEnded -= ReproducirAtaqueDespuesEnfado;
            mpsonidos.Source = MediaSource.CreateFromUri(new Uri("ms-appx:///AssetsDragoniteCSD/Ataque.mp3"));
            mpsonidos.Play();
        }

        private void ResetAnimation(bool cansado, bool herido)
        {
            sb.Stop();

            if (cansado)
            {
                sb = (Storyboard)this.Resources["Cansado"];
                sb.Begin();
            }
            else if (herido)
            {
                sb = (Storyboard)this.Resources["Herido"];
                sb.Begin();
            }
            else if (!cansado && !herido)
            {
                defaultStoryboard.Begin();
            }
        }

        private void usePotionRed(object sender, PointerRoutedEventArgs e)
        {
            dtTime = new DispatcherTimer();
            dtTime.Interval = TimeSpan.FromMilliseconds(100);
            dtTime.Tick += increaseHealth;
            dtTime.Start();
            this.img_pocionvida.Opacity = 0.5;
        }

        private void increaseHealth(object sender, object e)
        {
            this.pbVida.Value += 0.2;
            if (pbVida.Value >= 100)
            {
                this.dtTime.Stop();
                this.img_pocionvida.Opacity = 1;
            }
        }

        private void img_pocionvida_PointerReleased(object sender, PointerRoutedEventArgs e)
        {
            usePotionRed(sender, e);
        }



        public void VerFondo(bool ver)
        {
            if (!ver) { this.FondoPK.Background = null; }
            else
            {
                BitmapImage bitmapImage = new BitmapImage(new Uri("ms-appx:///AssetsDragoniteCSD/escenariopokemon.jpg"));
                ImageBrush imageBrush = new ImageBrush();
                imageBrush.ImageSource = bitmapImage;
                this.FondoPK.Background = imageBrush;

            }
        }

        public void VerFilaVida(bool ver)
        {
            if (!ver)
            {
                this.pbVida.Visibility = Visibility.Collapsed; // Oculta la ProgressBar de vida
            }
            else
            {
                this.pbVida.Visibility = Visibility.Visible; // Muestra la ProgressBar de vida
            }
        }

        public void VerFilaEnergia(bool ver)
        {
            if (!ver)
            {
                this.pbStamina.Visibility = Visibility.Collapsed; // Oculta la ProgressBar de energía
            }
            else
            {
                this.pbStamina.Visibility = Visibility.Visible; // Muestra la ProgressBar de energía
            }
        }



        public void VerPocionVida(bool ver)
        {
            if (!ver)
            {
                this.img_pocionvida.Source = null;
            }
            else
            {
                this.img_pocionvida.Source = new BitmapImage(new Uri("ms-appx:///AssetsDragoniteCSD/pocionvida.png"));
            }
        }



        public void VerPocionEnergia(bool ver)
        {
            if (!ver)
            {
                this.img_pocionstamina.Source = null; // Elimina la imagen de la poción de energía
            }
            else
            {
                // Asigna la imagen de la poción de energía nuevamente
                this.img_pocionstamina.Source = new BitmapImage(new Uri("ms-appx:///AssetsDragoniteCSD/pocionstamina.png"));
            }
        }


        public void VerNombre(bool ver)
        {
            if (!ver)
            {
                this.txtNombre.Visibility = Visibility.Collapsed;
            }
            else
            {
                this.txtNombre.Visibility = Visibility.Visible;
            }
        }


        public void ActivarAnimacionIdle(bool activar)
        {
            if (activar)
            {
                // Iniciar la animación por defecto de inactividad
                defaultStoryboard.Begin();
            }
            else
            {
                // Detener la animación por defecto de inactividad
                defaultStoryboard.Stop();
            }
        }

        public void AnimacionAtaqueFuerte()
        {
            sb.Stop();
            sb = (Storyboard)this.Resources["Cabezazo"];
            sb.Completed += (s, args) => ResetAnimation(cansado,herido);
            sb.Begin();
            mpsonidos.Source = MediaSource.CreateFromUri(new Uri("ms-appx:///AssetsDragoniteCSD/explosion.wav"));
            dtTime = new DispatcherTimer();
            dtTime.Interval = TimeSpan.FromMilliseconds(1000);
            dtTime.Tick += (s, args) =>
            {
                mpsonidos.Play();
                dtTime.Stop();
            };
            dtTime.Start();
        }

        public void AnimacionAtaqueFlojo()
        {
            sb.Stop();
            sb = (Storyboard)this.Resources["ColaDragon"];
            sb.Completed += (s, args) => ResetAnimation(cansado,herido);
            mpsonidos.MediaEnded += ReproducirAtaqueDespuesEnfado;
            mpsonidos.Source = MediaSource.CreateFromUri(new Uri("ms-appx:///AssetsDragoniteCSD/Enfado.mp3"));
            mpsonidos.Play();
            dtTime = new DispatcherTimer();
            dtTime.Interval = TimeSpan.FromMilliseconds(1300);
            dtTime.Tick += (s, args) =>
            {
                sb.Begin();
                dtTime.Stop();
            };
            dtTime.Start();
        }

        public void AnimacionDefensa()
        {
            sb.Stop();
            sb = (Storyboard)this.Resources["Escudo"];
            sb.Completed += (s, args) => ResetAnimation(cansado, herido);
            sb.Begin();
            mpsonidos.Source = MediaSource.CreateFromUri(new Uri("ms-appx:///AssetsDragoniteCSD/escudo.mp3"));
            dtTime = new DispatcherTimer();
            dtTime.Interval = TimeSpan.FromMilliseconds(1300);
            dtTime.Tick += (s, args) =>
            {
                mpsonidos.Play();
                dtTime.Stop();
            };
            dtTime.Start();
        }

        public void AnimacionDescansar()
        {
            sb.Stop();
            sb = (Storyboard)this.Resources["CuraVida"];
            sb.Completed += (s, args) => ResetAnimation(cansado, herido);
            mpsonidos.Source = MediaSource.CreateFromUri(new Uri("ms-appx:///AssetsDragoniteCSD/CuraVida.mp3"));
            mpsonidos.Play();
            dtTime = new DispatcherTimer();
            dtTime.Interval = TimeSpan.FromMilliseconds(800);
            dtTime.Tick += (s, args) =>
            {
                sb.Begin();
                dtTime.Stop();
            };
            dtTime.Start();
            cansado = false;
            herido = false;
        }

        public void AnimacionCansado()
        {
            sb.Stop();
            sb = (Storyboard)this.Resources["Cansado"];
            sb.Completed += (s, args) => ResetAnimation(cansado, herido);
            mpsonidos.Source = MediaSource.CreateFromUri(new Uri("ms-appx:///AssetsDragoniteCSD/cansado.mp3"));
            mpsonidos.Play();
            sb.Begin();
            cansado = true;
        }

        public void AnimacionNoCansado()
        {
            ResetAnimation(cansado, herido);
        }

        public void AnimacionHerido()
        {
            sb.Stop();
            sb = (Storyboard)this.Resources["Herido"];
            sb.Completed += (s, args) => ResetAnimation(cansado, herido);
            mpsonidos.Source = MediaSource.CreateFromUri(new Uri("ms-appx:///AssetsDragoniteCSD/herido.mp3"));
            mpsonidos.Play();
            dtTime = new DispatcherTimer();
            dtTime.Interval = TimeSpan.FromMilliseconds(1300);
            dtTime.Tick += (s, args) =>
            {
                sb.Begin();
                dtTime.Stop();
            };
            dtTime.Start();
            herido = true;
        }

        public void AnimacionNoHerido()
        {
            ResetAnimation(cansado, herido);
        }

        public void AnimacionDerrota()
        {
            sb.Stop();
            sb = (Storyboard)this.Resources["Muerte"];
            mpsonidos.Source = MediaSource.CreateFromUri(new Uri("ms-appx:///AssetsDragoniteCSD/muertedef.mp3"));
            mpsonidos.Play();
            sb.Begin();
            defaultStoryboard.Stop();
        }
    }


        internal interface iPokemon
    {
        double Vida { get; set; }
        double Energia { get; set; }
        string Nombre { get; set; } //Nombre del Pokemon
        string Categoria { get; set; } //Gas, Murciélago, Ratón..
        string Tipo { get; set; } //Eléctrico, Veneno, Volador...
        double Altura { get; set; } // En metros
        double Peso { get; set; } // En kilos
        string Evolucion { get; set; } // Nombre de la evolución o evoluciones
        string Descripcion { get; set; } // Entre 200 y 500 caracteres

        void VerFondo(bool ver);
        void VerFilaVida(bool ver);
        void VerFilaEnergia(bool ver);
        void VerPocionVida(bool ver);
        void VerPocionEnergia(bool ver);
        void VerNombre(bool ver);

        void ActivarAnimacionIdle(bool activar);
        void AnimacionAtaqueFlojo();
        void AnimacionAtaqueFuerte();
        void AnimacionDefensa();
        void AnimacionDescansar();

        void AnimacionCansado();
        void AnimacionNoCansado();
        void AnimacionHerido();
        void AnimacionNoHerido();
        void AnimacionDerrota();
    }
}

